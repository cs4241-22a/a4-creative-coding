Assignment 4 - Creative Coding: Interactive Multimedia Experiences
===


3D Audio Spectrum Visualizer
===
Sizhe Li, Link: https://a4-sizhe-li.glitch.me

This application displays 3d audio spectrum of default song(Ignite-Zedd.mp3). User can upload or drag the .mp3 file on their local drive to play.

1.User can change the color of the caps and bars of the spectrum.
2.Besides, User can also adjust the drop speed of the caps.
3.There is also an option to allow user to make this spectrum visualizer auto rotate.

Challenges
===
Getting familiar with and using Three.js to visualize music is fun and challenging.  
  
Trying to center the spectrum in 3d space and give the user the freedom to move the camera around is the most time consuming part.  
  
I spent a lot of time to get familiar with OrbitControls.js for doing that.  
  
In the lower right corner of the screen, I also add a simple info box that will help user monitor my code performance based on stat.js.  